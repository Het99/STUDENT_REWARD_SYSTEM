from django.contrib import admin
from srsapp.models import instructor
admin.site.register(instructor)
# Register your models here.
